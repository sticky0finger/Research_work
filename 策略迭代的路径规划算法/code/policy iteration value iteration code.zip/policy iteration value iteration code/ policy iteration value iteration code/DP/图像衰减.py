# 王淇正
# 开发时间：2023/5/17 13:05
# 王淇正
# 开发时间：2023/5/17 11:31
# 王淇正
# 开发时间：2023/4/25 13:08

import matplotlib.pyplot as plt
import numpy as np
from lib.envs.gridworld1 import GridworldEnv


def policy_eval(policy, env, discount_factor,threshold=0.01):
    '''
    策略评估方法
    :param policy:
    :param env:
    :param discount_factor:
    :param threshold:
    :return:
    '''
    # 初始化各状态的状态值函数
    V = np.zeros(env.nS)

    while True:
        value_delta = 0
        # 遍历各状态
        for s in range(env.nS):
            v = 0
            # 遍历各行为的概率(上,右,下,左)
            for a, action_prob in enumerate(policy[s]):
                # 对于每个行为确认下个状态
                # 四个参数: prob：概率, next_state: 下一个状态的索引, reward: 回报, done: 是否是终止状态
                for prob, next_state, reward, done in env.P[s][a]:
                    # 使用贝尔曼期望方程进行状态值函数的求解
                    v += action_prob * (reward + discount_factor * prob * V[next_state])
            # 求出各状态和上一次求得状态的最大差值
            value_delta = max(value_delta, np.abs(v - V[s]))
            V[s] = v

        # 当前循环得出的各状态和上一次状态的最大差值小于阈值,则收敛停止运算
        if value_delta < threshold:
            break
    return np.array(V)

def policy_improvement(v, policy,discount_factor):
    '''
    策略改进
    :param v:
    :param policy:
    `
    :param discount_factor:
    :return:
    '''

    def get_max_index(action_values):
        indexs = []
        policy_arr = np.zeros(len(action_values))

        action_max_value = np.max(action_values)

        for i in range(len(action_values)):
            action_value = action_values[i]

            if action_value == action_max_value:
                indexs.append(i)
                policy_arr[i] = 1
        return indexs, policy_arr

    # 定义一个标识来证明本次是否有提升
    policy_stable = True

    # 遍历各状态
    for s in range(env.nS):
        # 取出当前状态下最优行为的索引值
        chosen_a = np.argmax(policy[s])

        # 初始化行为数组[0,0,0,0]
        action_values = np.zeros(env.nA)
        for a in range(env.nA):
            # 遍历各行为
            for prob, next_state, reward, done in env.P[s][a]:
                # 根据各状态值函数求出行为值函数
                action_values[a] += (reward + discount_factor * prob * v[next_state])

        # 因为np.argmax(action_values)只会选取第一个最大值出现的索引,所以会丢掉其他方向的可能性,现在会输出一个状态下所有的可能性
        best_a_arr, policy_arr = get_max_index(action_values)

        # 如果求出的最大行为值函数的索引(方向)没有改变,则定义当前策略未改变，收敛输出
        # 否则将当前的状态中将有最大行为值函数的方向置1,其余方向置0
        if chosen_a not in best_a_arr:
            policy_stable = False
        policy[s] = policy_arr

    return policy_stable, policy


def policy_iteration_with_discount_factor(env, discount_factor):
    '''
    策略迭代函数，传入不同的折扣因子
    :param env:
    :param discount_factor:
    :return:
    '''
    policy = np.ones([env.nS, env.nA]) / env.nA
    iteration_count = 0

    while True:
        v = policy_eval(policy, env, discount_factor)
        policy_stable, policy = policy_improvement(v, policy, discount_factor)
        iteration_count += 1

        if policy_stable:
            return iteration_count

def plot_discount_iteration_curve(discount_factors, iteration_counts):
    fig, ax1 = plt.subplots()

    ax1.plot(discount_factors, iteration_counts, 'ro-')
    ax1.set_xlabel('Discount Factor')
    ax1.set_ylabel('Iteration Count')
    ax1.tick_params('y')
    ax1.set_yticks(np.arange(0,35,2))
    ax1.grid(True, color='black', linestyle='-', linewidth=0.5)
    ax1.set_facecolor('lightblue')
    ax1.set_xticks(np.arange(0.6, 1.05, 0.1))  # Set the x-axis range and interval

    fig.tight_layout()
    plt.show()



if __name__ == "__main__":
    env = GridworldEnv(r'G:\Users\Dell\Pictures\Saved Pictures\jiaju.jpg')

    decay_factors = np.arange(0.6, 1.05, 0.1)  # 修改范围，使其包括1.0
    iteration_counts = [policy_iteration_with_discount_factor(env, df) for df in decay_factors]
    plot_discount_iteration_curve(decay_factors, iteration_counts)
