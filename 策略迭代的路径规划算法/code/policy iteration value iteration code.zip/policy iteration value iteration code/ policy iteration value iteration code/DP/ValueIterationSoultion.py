#!/usr/bin/env python  
# encoding: utf-8  

""" 
@version: v1.0 
@license: Apache Licence
@software: PyCharm 
@file: ValueIterationSoultion.py 
@description: 值迭代
"""

import numpy as np
from lib.envs.gridworld import GridworldEnv

def value_iteration(env, discount_factor=1.0, threshold=0.00001):
    '''
    值迭代
    :param env:
    :param discount_factor:
    :param threshold:
    :return:
    '''
    def get_max_index(action_values):
        indexs = []
        policy_arr = np.zeros(len(action_values))

        action_max_value = np.max(action_values)

        for i in range(len(action_values)):
            action_value = action_values[i]

            if action_value == action_max_value:
                indexs.append(i)
                policy_arr[i] = 1
        return indexs, policy_arr

    def one_step_lookahead(state, v):
        q = np.zeros(env.nA)
        for a in range(env.nA):
            for prob, next_state, reward, done in env.P[state][a]:
                q[a] += (reward + discount_factor * prob * v[next_state])
        return q

    v = np.zeros(env.nS)

    while True:
        # 停止条件
        delta = 0
        # 遍历每个状态
        for s in range(env.nS):
            # 计算当前状态的值函数
            q = one_step_lookahead(s, v)
            # 找到最大值函数
            best_action_value = np.max(q)
            #  值函数更新前后求差
            delta = max(delta, np.abs(best_action_value - v[s]))
            # 更新当前状态的值函数，即：将最大的值函数赋值给值当前状态，用以更新当前状态的值函数
            v[s] = best_action_value

        # 如果当前状态的值函数更新前后相差小于阈值,则说明已经收敛,结束循环
        if delta < threshold:
            break

    # 初始化策略
    policy = np.zeros([env.nS, env.nA])
    # 遍历各状态
    for s in range(env.nS):
        # 根据已经计算出的V,计算当前状态的各值函数
        q = one_step_lookahead(s, v)
        # 求出当前最大值函数对应的动作索引
        # 将初始策略中的对应的状态上将最大值函数方向置1,其余方向保持不变,仍为0
        # 因为np.argmax(action_values)只会选取第一个最大值出现的索引,所以会丢掉其他方向的可能性,现在会输出一个状态下所有的可能性
        best_a_arr, policy_arr = get_max_index(q)
        # 将当前所有最优值赋值给当前状态
        policy[s] = policy_arr

    return policy, v

if __name__ == "__main__":
    env = GridworldEnv()
    policy, v = value_iteration(env)

    print("策略为:")
    print(policy.reshape([5,5,4]))

    print("值函数:")
    print(v)