# 王淇正
# 开发时间：2023/5/17 12:37
# 王淇正
# 开发时间：2023/4/25 13:08

import matplotlib.pyplot as plt
import numpy as np
from lib.envs.gridworld1 import GridworldEnv


def policy_eval(policy, env, discount_factor = 1.0,threshold=0.01):
    '''
    策略评估方法
    :param policy:
    :param env:
    :param discount_factor:
    :param threshold:
    :return:
    '''
    # 初始化各状态的状态值函数
    V = np.zeros(env.nS)

    while True:
        value_delta = 0
        # 遍历各状态
        for s in range(env.nS):
            v = 0
            # 遍历各行为的概率(上,右,下,左)
            for a, action_prob in enumerate(policy[s]):
                # 对于每个行为确认下个状态
                # 四个参数: prob：概率, next_state: 下一个状态的索引, reward: 回报, done: 是否是终止状态
                for prob, next_state, reward, done in env.P[s][a]:
                    # 使用贝尔曼期望方程进行状态值函数的求解
                    v += action_prob * (reward + discount_factor * prob * V[next_state])
            # 求出各状态和上一次求得状态的最大差值
            value_delta = max(value_delta, np.abs(v - V[s]))
            V[s] = v

        # 当前循环得出的各状态和上一次状态的最大差值小于阈值,则收敛停止运算
        if value_delta < threshold:
            break
    return np.array(V)

def policy_improvement(v, policy,discount_factor=1.0):
    '''
    策略改进
    :param v:
    :param policy:
    `
    :param discount_factor:
    :return:
    '''

    def get_max_index(action_values):
        indexs = []
        policy_arr = np.zeros(len(action_values))

        action_max_value = np.max(action_values)

        for i in range(len(action_values)):
            action_value = action_values[i]

            if action_value == action_max_value:
                indexs.append(i)
                policy_arr[i] = 1
        return indexs, policy_arr

    # 定义一个标识来证明本次是否有提升
    policy_stable = True

    # 遍历各状态
    for s in range(env.nS):
        # 取出当前状态下最优行为的索引值
        chosen_a = np.argmax(policy[s])

        # 初始化行为数组[0,0,0,0]
        action_values = np.zeros(env.nA)
        for a in range(env.nA):
            # 遍历各行为
            for prob, next_state, reward, done in env.P[s][a]:
                # 根据各状态值函数求出行为值函数
                action_values[a] += (reward + discount_factor * prob * v[next_state])

        # 因为np.argmax(action_values)只会选取第一个最大值出现的索引,所以会丢掉其他方向的可能性,现在会输出一个状态下所有的可能性
        best_a_arr, policy_arr = get_max_index(action_values)

        # 如果求出的最大行为值函数的索引(方向)没有改变,则定义当前策略未改变，收敛输出
        # 否则将当前的状态中将有最大行为值函数的方向置1,其余方向置0
        if chosen_a not in best_a_arr:
            policy_stable = False
        policy[s] = policy_arr

    return policy_stable, policy


def policy_iteration(env):
    '''
    策略迭代
    :param env:
    :return:
    '''
    policy = np.ones([env.nS, env.nA]) / env.nA
    iteration_count = 0

    # 更改为四个特定状态的价值函数
    iteration_values = [[] for _ in range(4)]

    selected_states = [0, 100, 150, 250]  # 选择四个状态

    while True:
        v = policy_eval(policy, env)
        for i, state in enumerate(selected_states):
            iteration_values[i].append(v[state])

        policy_stable, policy = policy_improvement(v, policy)
        iteration_count += 1

        if policy_stable:
            return policy, v, iteration_count, iteration_values


def plot_iteration_value_curve(iteration_count, iteration_values, selected_states):
    plt.figure()
    colors = ['r', 'g', 'b', 'y']
    state_labels = ['State ' + str(s) for s in selected_states]

    for i in range(len(selected_states)):
        plt.plot(range(1, iteration_count+1), iteration_values[i], colors[i] + 'o-', label=state_labels[i])

    plt.xlabel('Iteration Count')
    plt.ylabel('Value Function', labelpad=4)
    plt.grid(True, color='black', linestyle='-', linewidth=0.5)
    plt.gca().set_facecolor('lightblue')

    ax = plt.gca()

    # 修改坐标轴位置
    ax.spines['left'].set_position(('axes', -0.003)) # 将 y 轴向左移动
    ax.spines['bottom'].set_position('zero')
    ax.xaxis.tick_top()  # 将 x 轴的刻度放在上方
    ax.xaxis.set_label_position('top')  # 将 x 轴的标题放在上方

    # 更新坐标轴刻度
    ax.set_xticks(np.arange(1, 36, 5))  # 设置 x 轴的范围和刻度
    ax.set_yticks(np.arange(0, -30001, -3000))  # 设置 y 轴的范围和刻度
    ax.yaxis.set_tick_params(direction='out', pad=1)  # 设置 y 轴刻度向左移动
    [t.set_ha('left') for t in ax.get_xticklabels()]  # 将 x 轴的刻度标签向右移动

    # 设置坐标轴范围
    ax.set_xlim(0.5, 36)  # 将 x 轴的左侧边界调整为 0.5
    ax.set_ylim(-30000, 0)  # 设置 y 轴的范围

    # 设置图例位置
    plt.legend(loc='lower right')

    plt.show()

if __name__ == "__main__":
    env = GridworldEnv(r'G:\Users\Dell\Pictures\Saved Pictures\jiaju.jpg')
    policy, v, iteration_count, iteration_values = policy_iteration(env)

    print("策略为:")
    print(policy.reshape([env.shape[0], env.shape[1], 4]))

    print("值函数:")
    value_function = v.reshape(env.shape)
    print(value_function)

    print("策略迭代次数"+str(iteration_count))

    selected_states = [0, 100, 150, 250]
    plot_iteration_value_curve(iteration_count, iteration_values, selected_states)

