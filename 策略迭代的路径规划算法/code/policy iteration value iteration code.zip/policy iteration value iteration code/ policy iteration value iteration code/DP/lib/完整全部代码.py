# 王淇正
# 开发时间：2023/4/23 14:35
import random
import matplotlib.pyplot as plt
from gym.envs.toy_text import discrete
import numpy as np
from matplotlib.patches import FancyArrowPatch
from matplotlib.colors import ListedColormap
import seaborn as sns
from matplotlib.ticker import MaxNLocator
from matplotlib.colors import LinearSegmentedColormap

def policy_eval(policy, env, discount_factor=1.0, threshold=0.00001):
    '''
    策略评估方法
    :param policy:
    :param env:
    :param discount_factor:
    :param threshold:
    :return:
    '''
    # 初始化各状态的状态值函数
    V = np.zeros(env.nS)

    while True:
        value_delta = 0
        # 遍历各状态
        for s in range(env.nS):
            v = 0
            # 遍历各行为的概率(上,右,下,左)
            for a, action_prob in enumerate(policy[s]):
                # 对于每个行为确认下个状态
                # 四个参数: prob：概率, next_state: 下一个状态的索引, reward: 回报, done: 是否是终止状态
                for prob, next_state, reward, done in env.P[s][a]:
                    # 使用贝尔曼期望方程进行状态值函数的求解
                    v += action_prob * (reward + discount_factor * prob * V[next_state])
            # 求出各状态和上一次求得状态的最大差值
            value_delta = max(value_delta, np.abs(v - V[s]))
            V[s] = v

        # 当前循环得出的各状态和上一次状态的最大差值小于阈值,则收敛停止运算
        if value_delta < threshold:
            break
    return np.array(V)

def policy_improvement(v, policy, discount_factor=1.0):
    '''
    策略改进
    :param v:
    :param policy:
    :param discount_factor:
    :return:
    '''
    def get_max_index(action_values):
        indexs = []
        policy_arr = np.zeros(len(action_values))

        action_max_value = np.max(action_values)

        for i in range(len(action_values)):
            action_value = action_values[i]

            if action_value == action_max_value:
                indexs.append(i)
                policy_arr[i] = 1
        return indexs, policy_arr

    # 定义一个标识来证明本次是否有提升
    policy_stable = True

    # 遍历各状态
    for s in range(env.nS):
        # 取出当前状态下最优行为的索引值
        chosen_a = np.argmax(policy[s])

        # 初始化行为数组[0,0,0,0]
        action_values = np.zeros(env.nA)
        for a in range(env.nA):
            # 遍历各行为
            for prob, next_state, reward, done in env.P[s][a]:
                # 根据各状态值函数求出行为值函数
                action_values[a] += (reward + discount_factor * prob * v[next_state])

        # 因为np.argmax(action_values)只会选取第一个最大值出现的索引,所以会丢掉其他方向的可能性,现在会输出一个状态下所有的可能性
        best_a_arr, policy_arr = get_max_index(action_values)

        # 如果求出的最大行为值函数的索引(方向)没有改变,则定义当前策略未改变，收敛输出
        # 否则将当前的状态中将有最大行为值函数的方向置1,其余方向置0
        if chosen_a not in best_a_arr:
            policy_stable = False
        policy[s] = policy_arr

    return policy_stable, policy

def policy_iteration(env):
    '''
    策略迭代
    :param env:
    :return:
    '''
    policy = np.ones([env.nS, env.nA]) / env.nA

    while True:
        # 评估当前的策略,输出为各状态的当前的状态值函数
        v = policy_eval(policy, env)
        # 进行策略改进
        policy_stable, policy = policy_improvement(v, policy)

        # 如果当前策略没有发生改变,即已经到了最优策略,返回
        if policy_stable:
            return policy, v


def plot_heatmap(value_function, min_value, max_value):
    plt.figure(figsize=(env.shape[0], env.shape[0]))  # Modify figsize here
    custom_cmap = LinearSegmentedColormap.from_list("green_white_red", ["darkgreen","lightgreen", "white", "lightsalmon", "darkred"])
    ax = sns.heatmap(value_function, annot=True, fmt='.1f', cmap=custom_cmap, vmin=min_value, vmax=max_value, cbar_kws={'label': 'Value Function'})
    ax.xaxis.set_major_locator(MaxNLocator(integer=True))   #设置 X 轴和 Y 轴的主要刻度，使其为整数。
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    plt.tick_params(axis='both', which='both', bottom=False, top=False, left=False, right=False, labelbottom=False, labelleft=False) #设置刻度线参数，隐藏所有刻度线和标签。
    ax.collections[0].colorbar.outline.set_visible(False) #隐藏颜色条周围的轮廓。在这里，设置为 False 表示不显示轮廓。
    ax.collections[0].colorbar.ax.set_ylim(min_value, max_value) #设置颜色条的 y 轴范围
    ax.collections[0].colorbar.ax.yaxis.set_ticks([min_value, max_value]) #设置颜色条 y 轴上的刻度
    ax.collections[0].colorbar.ax.yaxis.set_ticklabels([f'{min_value:.1f}', f'{max_value:.1f}']) #设置颜色条Y轴刻度标签的显示格式为保留一位小数的浮点数。

    #设置热力图边框的属性并显示图像
    for _, spine in ax.spines.items():
        spine.set_visible(True)
        spine.set_color('black')
        spine.set_linewidth(2)

    plt.show()


def plot_decay_iteration_curve(decay_factors, iteration_counts):
    plt.figure()
    plt.plot(decay_factors, iteration_counts, 'ro-')
    plt.xlabel('Decay Factor')
    plt.ylabel('Iteration Count')
    plt.grid(True, color='black', linestyle='-', linewidth=0.5)
    plt.gca().set_facecolor('lightblue')

    ax = plt.gca()

    # 修改坐标轴位置
    ax.spines['left'].set_position('zero')   # 将 y 轴移动到零点
    ax.spines['bottom'].set_position('zero') # 将 x 轴移动到零点

    # 更新坐标轴刻度
    ax.set_xticks(np.arange(0, 1.1, 0.1))
    ax.set_yticks(np.arange(0, 101, 20))

    # 更新坐标轴刻度标签
    ax.set_xticklabels([f'{x:.1f}' for x in np.arange(0, 1.1, 0.1)], ha='left')
    ax.set_yticklabels(np.arange(0, 101, 20), va='bottom')

    plt.show()

UP = 0
RIGHT = 1
DOWN = 2
LEFT = 3
OBSTACLE_REWARD = -3

class GridworldEnv(discrete.DiscreteEnv):
    def __init__(self, shape=(6, 6), num_obstacles=5):
        self.shape = shape
        self.start = (0, 0)
        self.goal = (shape[0] - 1, shape[1] - 1)
        self.num_obstacles = num_obstacles

        nS = np.prod(shape)
        nA = 4

        MAX_X = shape[0]
        MAX_Y = shape[1]

        P = {}
        grid = np.arange(nS).reshape(shape)
        it = np.nditer(grid, flags=['multi_index'])

        # Generate random obstacles
        obstacles = set()
        while len(obstacles) < num_obstacles:
            obs = random.randint(0, nS - 1)
            if obs not in (0, nS - 1):  # Make sure the start and goal states are not obstacles
                obstacles.add(obs)

        self.obstacles = obstacles

        while not it.finished:
            s = it.iterindex
            x, y = it.multi_index

            P[s] = {a: [] for a in range(nA)}

            is_start = lambda s: s == 0
            is_goal = lambda s: s == nS - 1
            is_obstacle = lambda s: s in obstacles

            if is_goal(s):
                reward = 0.0
            elif is_obstacle(s):
                reward = OBSTACLE_REWARD
            elif is_start(s):
                reward = -1.0
            else:
                reward = -1.0

            # if a terminal state
            if is_goal(s):
                P[s][UP] = [(1, s, reward, True)]
                P[s][RIGHT] = [(1, s, reward, True)]
                P[s][DOWN] = [(1, s, reward, True)]
                P[s][LEFT] = [(1, s, reward, True)]


#P是环境中的转移概率矩阵。它是一个嵌套的字典结构，第一层键是状态，第二层键是动作，对应的值是一个列表，列表中的每个元素是一个四元组，表示（转移概率，下一个状态，奖励，结束标志）。
                # Not a terminal state
            else:
                ns_up = s if x == 0 else s - MAX_X
                ns_right = s if y == (MAX_Y - 1) else s + 1
                ns_down = s if x == (MAX_X - 1) else s + MAX_X
                ns_left = s if y == 0 else s - 1
                P[s][UP] = [(1, ns_up, reward, is_goal(ns_up))]
                P[s][RIGHT] = [(1, ns_right, reward, is_goal(ns_right))]
                P[s][DOWN] = [(1, ns_down, reward, is_goal(ns_down))]
                P[s][LEFT] = [(1, ns_left, reward, is_goal(ns_left))]

            it.iternext()

        isd = np.ones(nS) / nS

        super(GridworldEnv, self).__init__(nS, nA, P, isd)

    def render(self, path=None):
        grid = np.zeros(self.shape)
        for obs in self.obstacles:
            x, y = np.unravel_index(obs, self.shape)
            grid[x, y] = -1    #格子的类型为障碍

        grid[self.start] = 1    #格子的类型为起点
        grid[self.goal] = 2     #格子的类型为终点

        if path:    #标记网格世界中智能体所走过的路径
            for s in path:
                x, y = np.unravel_index(s, self.shape)
                if (x, y) != self.start and (x, y) != self.goal:
                    grid[x, y] = 0  #表示路径上的普通格子

        # Create custom colormap
        cmap = ListedColormap(['purple', 'lightgray', 'yellow', 'blue'])

        plt.figure(figsize=(self.shape[0], self.shape[1]))
        plt.imshow(grid, cmap=cmap)
        plt.xticks(np.arange(-0.5, self.shape[0], 1), []) #生成一个从-0.5开始，以1为间隔的序列，直到self.shape[0]（行数）为止。这些值将作为x轴的刻度位置。传入空列表 [] 表示不显示x轴上的刻度标签。
        plt.yticks(np.arange(-0.5, self.shape[1], 1), [])
        plt.grid(which='both', color='black', linewidth=1.0) # 在图形上绘制网格线

        if path:
            ax = plt.gca() #获取当前的坐标轴对象，用于添加箭头
            for i in range(len(path) - 1):
                start_pos = np.unravel_index(path[i], self.shape) #将路径中的当前状态（一维索引）转换为二维索引（行和列），得到起始位置
                end_pos = np.unravel_index(path[i + 1], self.shape)
                arrow = FancyArrowPatch(start_pos[::-1], end_pos[::-1], color='red', arrowstyle='->', mutation_scale=20,lw=2) #start_pos[::-1] 和 end_pos[::-1] 将行和列索引颠倒，以符合matplotlib的坐标系。
                ax.add_patch(arrow)

        plt.show()

if __name__ == "__main__":
    env = GridworldEnv()
    policy, v = policy_iteration(env)

    print("策略为:")
    print(policy.reshape([env.shape[0], env.shape[1],4]))

    print("值函数:")
    value_function = v.reshape(env.shape)
    print(value_function)

    # Get the path from start to goal
    current_state = 0
    path = [current_state]
    while current_state != env.nS - 1:
        action = np.argmax(policy[current_state])
        _, next_state, _, _ = env.P[current_state][action][0]  #从转移概率矩阵中获取下一个状态，并将其赋值给变量 next_state。其他三个我们不关心的值使用 _ 表示。
        path.append(next_state)
        current_state = next_state

    env.render(path=path)

    min_value = value_function.min()
    max_value = value_function.max()

    plot_heatmap(value_function, min_value, max_value)

    decay_factors = np.arange(0, 1.1, 0.1)
    iteration_counts = np.array([10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110])

    plot_decay_iteration_curve(decay_factors, iteration_counts)

# 帮我修改上面的代码，对gridworldenv环境进行修改可以实现打开一张图片并将其转换为二值图像，然后处理这张二值图像，将其转化为一个强化学习的环境（即网格世界），并定义了状态转移和奖励函数。这样，通过前面的策略迭代算法就可以在这个环境中学习如何做出最优的决策，用时利用上面的render函数可以绘制出路径的箭头
"""
def policy_iteration(env):
    '''
    策略迭代
    :param env:
    :return:
    '''
    policy = np.ones([env.nS, env.nA]) / env.nA
    iteration_count = 0

    # 更改为四个特定状态的价值函数
    iteration_values = [[] for _ in range(4)]

    selected_states = [0, 10, 20, 30]  # 选择四个状态

    while True:
        v = policy_eval(policy, env)
        for i, state in enumerate(selected_states):
            iteration_values[i].append(v[state])

        policy_stable, policy = policy_improvement(v, policy)
        iteration_count += 1

        if policy_stable:
            return policy, v, iteration_count, iteration_values


def plot_iteration_value_curve(iteration_count, iteration_values, selected_states):
    plt.figure()
    colors = ['r', 'g', 'b', 'y']
    state_labels = ['State ' + str(s) for s in selected_states]

    for i in range(len(selected_states)):
        plt.plot(range(iteration_count), iteration_values[i], colors[i] + 'o-', label=state_labels[i])

    plt.xlabel('Iteration Count')
    plt.ylabel('Value Function of Selected States')
    plt.grid(True, color='black', linestyle='-', linewidth=0.5)
    plt.gca().set_facecolor('lightblue')

    ax = plt.gca()

    # 修改坐标轴位置
    ax.spines['left'].set_position('zero')
    ax.spines['bottom'].set_position('zero')
    ax.xaxis.tick_top()  # 将 x 轴的刻度放在上方
    ax.xaxis.set_label_position('top')  # 将 x 轴的标题放在上方

    # 更新坐标轴刻度
    ax.set_xticks(np.arange(0, 31, 5))
    ax.set_yticks(np.arange(-400, 1, 50))  # 设置 y 轴的范围和刻度
    ax.yaxis.set_tick_params(direction='out', pad=8)  # 设置 y 轴刻度向左移动

    # 设置坐标轴范围
    ax.set_xlim(-1, 30)  # 将 x 轴的左侧边界调整为 -1
    ax.set_ylim(-400, 0)  # 设置 y 轴的范围

    # 设置图例位置
    plt.legend(loc='center right')

    plt.show()
    
    
if __name__ == "__main__":
    env = GridworldEnv()
    policy, v, iteration_count, iteration_values = policy_iteration(env)

    print("策略为:")
    print(policy.reshape([env.shape[0], env.shape[1], 4]))

    print("值函数:")
    value_function = v.reshape(env.shape)
    print(value_function)

    print("策略迭代次数"+str(iteration_count))

    selected_states = [0, 10, 20, 30]
    plot_iteration_value_curve(iteration_count, iteration_values, selected_states)
"""


"""
def policy_iteration_with_discount_factor(env, discount_factor):
    '''
    策略迭代函数，传入不同的折扣因子
    :param env:
    :param discount_factor:
    :return:
    '''
    policy = np.ones([env.nS, env.nA]) / env.nA
    iteration_count = 0

    while True:
        v = policy_eval(policy, env, discount_factor)
        policy_stable, policy = policy_improvement(v, policy, discount_factor)
        iteration_count += 1

        if policy_stable:
            return iteration_count

def plot_discount_iteration_curve(discount_factors, iteration_counts):
    plt.figure()
    plt.plot(discount_factors, iteration_counts, 'ro-')
    plt.xlabel('Discount Factor')
    plt.ylabel('Iteration Count')
    plt.grid(True, color='black', linestyle='-', linewidth=0.5)
    plt.gca().set_facecolor('lightblue')

    ax = plt.gca()

    # 修改坐标轴位置
    ax.spines['left'].set_position('zero')   # 将 y 轴移动到零点
    ax.spines['bottom'].set_position('zero') # 将 x 轴移动到零点

    # 更新坐标轴刻度
    ax.set_xticks(np.arange(0, 1.1, 0.1))
    ax.set_yticks(np.arange(0, 101, 20))

    plt.show()


    decay_factors = np.arange(0.5, 1.05, 0.1)  # 修改范围，使其包括1.0
    iteration_counts = [policy_iteration_with_discount_factor(env, df) for df in decay_factors]
    plot_discount_iteration_curve(decay_factors, iteration_counts)
"""