# 王淇正
# 开发时间：2023/5/11 21:12

# 王淇正
# 开发时间：2023/5/11 21:12

import cv2
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
from gym.envs.toy_text import discrete

UP = 0
RIGHT = 1
DOWN = 2
LEFT = 3

class GridworldEnv(discrete.DiscreteEnv):
    def __init__(self, img_path, start=(0, 0), goal=None):
        self.img_path = img_path
        self.shape = (16, 16)
        self.start = start
        self.goal = goal if goal else (self.shape[0] - 1, self.shape[1] - 1)
        self.grid, self.avg_gray = self.prepare_grid_and_rewards()

        nS = np.prod(self.shape)
        nA = 4

        MAX_X = self.shape[0]
        MAX_Y = self.shape[1]

        P = {}
        grid = np.arange(nS).reshape(self.shape)
        it = np.nditer(grid, flags=['multi_index'])

        while not it.finished:
            s = it.iterindex
            x, y = it.multi_index

            P[s] = {a: [] for a in range(nA)}

            is_start = lambda s: s == 0
            is_goal = lambda s: s == nS - 1
            is_obstacle = lambda x, y: self.grid[x][y] == 0

            if is_goal(s):
                reward = 0.0
            elif is_obstacle(x,y):
                reward = -10
            elif is_start(s):
                reward = -1.0
            else:
                reward = -1.0

            # If a terminal state
            if is_goal(s):
                P[s][UP] = [(1, s, reward, True)]
                P[s][RIGHT] = [(1, s, reward, True)]
                P[s][DOWN] = [(1, s, reward, True)]
                P[s][LEFT] = [(1, s, reward, True)]
            # Not a terminal state
            else:
                ns_up = s if x == 0 else s - MAX_X
                ns_right = s if y == (MAX_Y - 1) else s + 1
                ns_down = s if x == (MAX_X - 1) else s + MAX_X
                ns_left = s if y == 0 else s - 1
                P[s][UP] = [(1, ns_up, reward, is_goal(ns_up))]
                P[s][RIGHT] = [(1, ns_right, reward, is_goal(ns_right))]
                P[s][DOWN] = [(1, ns_down, reward, is_goal(ns_down))]
                P[s][LEFT] = [(1, ns_left, reward, is_goal(ns_left))]

            it.iternext()

        isd = np.ones(nS) / nS

        super(GridworldEnv, self).__init__(nS, nA, P, isd)

    def prepare_grid_and_rewards(self):
        img = cv2.imread(self.img_path, cv2.IMREAD_GRAYSCALE)
        original_shape = img.shape
        block_size_x = original_shape[0] // self.shape[0]
        block_size_y = original_shape[1] // self.shape[1]

        grid = np.zeros(self.shape)
        all_avg_values = []
        for i in range(self.shape[0]):
            for j in range(self.shape[1]):
                # Calculate average grayscale value in the block
                block = img[i * block_size_x:(i + 1) * block_size_x, j * block_size_y:(j + 1) * block_size_y]
                avg_value = np.mean(block)
                all_avg_values.append(avg_value)
                # If avg_value is less than or equal to the overall average, it is an obstacle
                grid[i][j] = 0 if avg_value <= np.mean(all_avg_values) else 1

        return grid, np.mean(all_avg_values)

    def render(self, path=None):
        original_img = cv2.cvtColor(cv2.imread(self.img_path), cv2.COLOR_BGR2RGB)
        original_img = cv2.resize(original_img, (self.shape[1] * 10, self.shape[0] * 10))  # Resizing the image
        plt.figure(figsize=(self.shape[1], self.shape[0]), dpi=100)
        plt.imshow(original_img)

        # Adjusting the grid lines to match the enlarged image
        plt.xticks(np.arange(-0.5, self.shape[1] * 10, 10), [])
        plt.yticks(np.arange(-0.5, self.shape[0] * 10, 10), [])
        plt.grid(which='both', color='black', linewidth=1.0)  # Add grid lines

        if path:
            ax = plt.gca()  # Get current axis, to add arrows
            for i in range(len(path) - 1):
                start_pos = np.unravel_index(path[i], self.shape)
                end_pos = np.unravel_index(path[i + 1], self.shape)

                # Adjusting the start and end positions to match the enlarged image
                # Adding an offset to place the arrow in the middle of the grid cell
                start_pos = (start_pos[0] * 10 + 5, start_pos[1] * 10 + 5)
                end_pos = (end_pos[0] * 10 + 5, end_pos[1] * 10 + 5)

                arrow = FancyArrowPatch(start_pos[::-1], end_pos[::-1], color='red', arrowstyle='->', mutation_scale=20,lw=1)
                ax.add_patch(arrow)

        plt.show()


