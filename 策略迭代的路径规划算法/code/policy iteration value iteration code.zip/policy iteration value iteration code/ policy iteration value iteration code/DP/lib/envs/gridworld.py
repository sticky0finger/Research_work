"""
Grid World environment from Sutton's Reinforcement Learning book chapter 4.
You are an agent on an MxN grid and your goal is to reach the terminal
state at the top left or the bottom right corner.

For example, a 5x5 grid looks as follows:

o  o  o  o  o
o  o  o  T  o   # DONE_LOCATION == 8
o  o  o  o  o
o  x  o  o  o
o  o  o  o  o

x is your position and T are the two terminal states.

You can take actions in each direction (UP=0, RIGHT=1, DOWN=2, LEFT=3).
Actions going off the edge leave you in your current state.
You receive a reward of -1 at each step until you reach a terminal state.
"""

import random
import matplotlib.pyplot as plt
from gym.envs.toy_text import discrete
import numpy as np
from matplotlib.patches import FancyArrowPatch
from matplotlib.colors import ListedColormap


UP = 0
RIGHT = 1
DOWN = 2
LEFT = 3
OBSTACLE_REWARD = -3

class GridworldEnv(discrete.DiscreteEnv):
    def __init__(self, shape=(7 , 7), num_obstacles=6):
        self.shape = shape
        self.start = (0, 0)
        self.goal = (shape[0] - 1, shape[1] - 1)
        self.num_obstacles = num_obstacles

        nS = np.prod(shape)
        nA = 4

        MAX_X = shape[0]
        MAX_Y = shape[1]

        P = {}
        grid = np.arange(nS).reshape(shape)
        it = np.nditer(grid, flags=['multi_index'])

        # Generate random obstacles
        obstacles = set()
        while len(obstacles) < num_obstacles:
            obs = random.randint(0, nS - 1)
            if obs not in (0, nS - 1):                      # Make sure the start and goal states are not obstacles
                obstacles.add(obs)

        self.obstacles = obstacles

        """"
        obstacles = set()
        fixed_obstacles = [2, 13, 20, 25, 30, 34]  # Specify the fixed obstacle positions

        for obs in fixed_obstacles:
            if obs not in (0, nS - 1):  # Make sure the start and goal states are not obstacles
                obstacles.add(obs)

        self.obstacles = obstacles
        """
        while not it.finished:
            s = it.iterindex
            x, y = it.multi_index

            P[s] = {a: [] for a in range(nA)}

            is_start = lambda s: s == 0
            is_goal = lambda s: s == nS - 1
            is_obstacle = lambda s: s in obstacles

            if is_goal(s):
                reward = 0
            elif is_obstacle(s):
                reward = OBSTACLE_REWARD
            elif is_start(s):
                reward = -1
            else:
                reward = -1

            # if a terminal state
            if is_goal(s):
                P[s][UP] = [(1, s, reward, True)]
                P[s][RIGHT] = [(1, s, reward, True)]
                P[s][DOWN] = [(1, s, reward, True)]
                P[s][LEFT] = [(1, s, reward, True)]


#P是环境中的转移概率矩阵。它是一个嵌套的字典结构，第一层键是状态，第二层键是动作，对应的值是一个列表，列表中的每个元素是一个四元组，表示（转移概率，下一个状态，奖励，结束标志）。
                # Not a terminal state
            else:
                ns_up = s if x == 0 else s - MAX_X
                ns_right = s if y == (MAX_Y - 1) else s + 1
                ns_down = s if x == (MAX_X - 1) else s + MAX_X
                ns_left = s if y == 0 else s - 1
                P[s][UP] = [(1, ns_up, reward, is_goal(ns_up))]
                P[s][RIGHT] = [(1, ns_right, reward, is_goal(ns_right))]
                P[s][DOWN] = [(1, ns_down, reward, is_goal(ns_down))]
                P[s][LEFT] = [(1, ns_left, reward, is_goal(ns_left))]

            it.iternext()

        isd = np.ones(nS) / nS

        super(GridworldEnv, self).__init__(nS, nA, P, isd)

    def render(self, path=None):
        grid = np.zeros(self.shape)
        for obs in self.obstacles:
            x, y = np.unravel_index(obs, self.shape)
            grid[x, y] = -1    #格子的类型为障碍

        grid[self.start] = 1    #格子的类型为起点
        grid[self.goal] = 2     #格子的类型为终点

        if path:    #标记网格世界中智能体所走过的路径
            for s in path:
                x, y = np.unravel_index(s, self.shape)
                if (x, y) != self.start and (x, y) != self.goal:
                    grid[x, y] = 0  #表示路径上的普通格子

        # Create custom colormap
        cmap = ListedColormap(['purple', 'lightgray', 'yellow', 'blue'])

        plt.figure(figsize=(self.shape[0], self.shape[1]))
        plt.imshow(grid, cmap=cmap)
        plt.xticks(np.arange(-0.5, self.shape[0], 1), []) #生成一个从-0.5开始，以1为间隔的序列，直到self.shape[0]（行数）为止。这些值将作为x轴的刻度位置。传入空列表 [] 表示不显示x轴上的刻度标签。
        plt.yticks(np.arange(-0.5, self.shape[1], 1), [])
        plt.grid(which='both', color='black', linewidth=1.0) # 在图形上绘制网格线

        if path:
            ax = plt.gca() #获取当前的坐标轴对象，用于添加箭头
            for i in range(len(path) - 1):
                start_pos = np.unravel_index(path[i], self.shape) #将路径中的当前状态（一维索引）转换为二维索引（行和列），得到起始位置
                end_pos = np.unravel_index(path[i + 1], self.shape)
                arrow = FancyArrowPatch(start_pos[::-1], end_pos[::-1], color='red', arrowstyle='->', mutation_scale=20,lw=2) #start_pos[::-1] 和 end_pos[::-1] 将行和列索引颠倒，以符合matplotlib的坐标系。
                ax.add_patch(arrow)

        plt.show()



